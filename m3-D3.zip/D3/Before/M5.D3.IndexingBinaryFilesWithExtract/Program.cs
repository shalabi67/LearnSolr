﻿using M5.D3.IndexingBinaryFilesWithExtract.Models;
using Microsoft.Practices.ServiceLocation;
using SolrNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M5.D3.IndexingBinaryFilesWithExtract
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initialize connection to Solr using SolrNet

            //Iterate over the files
            //foreach (string filename in ...))
            //{
                //Open file using FileStream
                
                //And upload using extract
            //}
            
            //Don't forget to commit!
        }
    }
}
