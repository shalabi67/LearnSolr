﻿using M5.D2.IndexAllCourses.Models;
using Microsoft.Practices.ServiceLocation;

using SolrNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexAllCourses
{
    class Program
    {
        static void Main(string[] args)
        {
            //Delete courses before starting this demo

            //Read file and deserialize using Json.Net (or feel free to use any other method)
            
            //Initialize SolrNet
            
            //Index courses

            //Commit            
        }
    }
}
