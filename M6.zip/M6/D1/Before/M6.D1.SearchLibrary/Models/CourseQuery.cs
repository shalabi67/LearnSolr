﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SearchLibrary.Models
{
    public class CourseQuery
    {
        //Query object that holds parameters sent to the search library
    }
}