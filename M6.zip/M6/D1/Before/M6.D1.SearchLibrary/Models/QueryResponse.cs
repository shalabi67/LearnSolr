﻿using SolrNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SearchLibrary.Models
{
    public class QueryResponse
    {
        public QueryResponse()
        {
            //Initialize properties
        }

        //Expose properties that will be returned to from the search library
    }
}