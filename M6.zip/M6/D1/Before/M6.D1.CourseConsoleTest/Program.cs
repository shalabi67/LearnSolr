﻿using SearchLibrary;
using SearchLibrary.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            throw new NotImplementedException();
            //create a search library instance

            //create a query object to hold the user query

            //read the query

            //And print out the results
        }
    }
}
