﻿using SearchLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseConsoleTest
{
    internal static class QueryReader
    {
        internal static CourseQuery ReadQuery()
        {
            throw new NotImplementedException();
            //Create a query object

            //Read the query

            //return the query object            
        }
    }
}
